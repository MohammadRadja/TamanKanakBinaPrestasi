@extends('ppdbtk.template')


@section('judul', 'Dashboard')

@section('content')

@endsection