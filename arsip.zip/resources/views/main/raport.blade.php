@extends('ppdbtk.template')

@section('judul', 'Raport')

@section('content')
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>Mata Pelajaran</th>
                <th>Nilai</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($raport as $r)
            <tr>
                <td>{{ $r->mapel }}</td>
                <td>{{ $r->nilai }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<div class="row mt-3">
    <div class="col-md-6">
        <h5>Rata-rata Nilai Raport</h5>
        <p>{{ $rataRataNilai }}</p>
    </div>
</div>
@endsection
