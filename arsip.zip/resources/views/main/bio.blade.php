@extends('ppdbtk.template')
@section('judul', 'Biodata Siswa')
@section('content')
<!-- biodata -->

<div class="col-md-10 p-5 pt-5">

    <h3><i class="fa-solid fa-user-graduate"></i>BIODATA</h3>
    <hr>
    <div class="container">
        @if (session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <form class="row" action="/save" method="POST">
            @csrf
            <div class="col-md-6 mx-auto">
                <div class="mb-3">
                    <label for="fullName" class="form-label">Nama Lengkap</label>
                    <input type="text" name="fullName" class="form-control" id="fullName" value="{{ $biodata ? $biodata->nama_lengkap : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="nickName" class="form-label">Nama Panggilan</label>
                    <input type="text" name="nickName" class="form-control" id="nickName" value="{{ $biodata ? $biodata->nama_panggilan : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="gender" class="form-label">Jenis Kelamin</label>
                    <select name="gender" class="form-select" id="gender" required>
                        <option value="" selected disabled>Pilih</option>
                        <option value="laki-laki" {{ $biodata && $biodata->jenis_kelamin == 'laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                        <option value="perempuan" {{ $biodata && $biodata->jenis_kelamin == 'perempuan' ? 'selected' : '' }}>Perempuan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="birthPlaceDate" class="form-label">Tempat, Tanggal Lahir</label>
                    <input type="text" name="birthPlaceDate" class="form-control" id="birthPlaceDate" value="{{ $biodata ? $biodata->tempat_tanggal_lahir : '' }}" placeholder="Contoh: Jakarta, 1 Januari 2024" required />
                </div>
                <div class="mb-3">
                    <label for="agama" class="form-label">Agama</label>
                    <select name="agama" class="form-select" id="agama" required>
                        <option value="" selected disabled>Pilih</option>
                        <option value="islam" {{ $biodata && $biodata->agama == 'islam' ? 'selected' : '' }}>Islam</option>
                        <option value="kristen protestan" {{ $biodata && $biodata->agama == 'kristen protestan' ? 'selected' : '' }}>Kristen Protestan</option>
                        <option value="kristen katolik" {{ $biodata && $biodata->agama == 'kristen katolik' ? 'selected' : '' }}>Kristen Katolik</option>
                        <option value="hindu" {{ $biodata && $biodata->agama == 'hindu' ? 'selected' : '' }}>Hindu</option>
                        <option value="buddha" {{ $biodata && $biodata->agama == 'buddha' ? 'selected' : '' }}>Buddha</option>
                        <option value="konghucu" {{ $biodata && $biodata->agama == 'konghucu' ? 'selected' : '' }}>Konghucu</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="anakKe" class="form-label">Anak ke-</label>
                    <input type="text" name="anakKe" class="form-control" id="anakKe" value="{{ $biodata ? $biodata->anak_ke : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="parentNameAyah" class="form-label">Nama Ayah</label>
                    <input type="text" name="parentNameAyah" class="form-control" id="parentNameAyah" value="{{ $biodata ? $biodata->nama_ayah : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="parentNameIbu" class="form-label">Nama Ibu</label>
                    <input type="text" name="parentNameIbu" class="form-control" id="parentNameIbu" value="{{ $biodata ? $biodata->nama_ibu : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="profesiayah" class="form-label">Pekerjaan Ayah</label>
                    <input type="text" name="profesiayah" class="form-control" id="profesiayah" value="{{ $biodata ? $biodata->pekerjaan_ayah : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="profesiibu" class="form-label">Pekerjaan Ibu</label>
                    <input type="text" name="profesiibu" class="form-control" id="profesiibu" value="{{ $biodata ? $biodata->pekerjaan_ibu : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="telayah" class="form-label">No. HP/WhatsApp</label>
                    <input type="text" name="telayah" class="form-control" id="telayah" value="{{ $biodata ? $biodata->no_hp : '' }}" required />
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Alamat Rumah</label>
                    <textarea name="address" class="form-control" id="address" rows="3" required>{{ $biodata ? $biodata->alamat : '' }}</textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-lg">Simpan</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection