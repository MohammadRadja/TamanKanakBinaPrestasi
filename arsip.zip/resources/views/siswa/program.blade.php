@extends('master.template')
@section('Judul', 'Program')
@section('content')
    <!-- program -->
    <div class="container py-5 menu">
        <h1 class="text-center">EKSTRAKURIKULER DAN PROGRAM</h1>
        <div class="row pt-4 gx-4 gy-4">
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-running fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body text-center">
                        <h5 class="card-title">Silat</h5>
                        <p class="card-text">
                            Mendorong anak-anak untuk bergerak aktif dan meningkatkan
                            kesehatan fisik mereka.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-paint-brush fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body text-center">
                        <h5 class="card-title">Melukis</h5>
                        <p class="card-text">
                            Mengembangkan kreativitas anak-anak melalui kegiatan melukis dan
                            menggambar.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-music fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body text-center">
                        <h5 class="card-title">Menari</h5>
                        <p class="card-text">
                            Mengenalkan anak-anak pada dunia musik melalui menyanyi dan
                            bermain alat musik sederhana.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-theater-masks fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body text-center">
                        <h5 class="card-title">Komputer</h5>
                        <p class="card-text">
                            Membantu anak-anak dalam ekspresi diri dan kemampuan berbicara
                            melalui bercerita dan bermain drama.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-puzzle-piece fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body text-center">
                        <h5 class="card-title">Tahfidz</h5>
                        <p class="card-text">
                            Merangsang imajinasi dan kreativitas anak-anak melalui permainan
                            kreatif dan eksperimental.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card crop-img">
                    <i class="fas fa-hands-helping fa-5x text-primary mb-3 text-center"></i>
                    <div class="card-body ">
                        <h5 class="card-title">Manasik Haji</h5>
                        <p class="card-text">
                            Mengajarkan anak-anak tentang nilai-nilai moral dan perilaku
                            yang baik.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- penutup program -->
    <!-- fasilitas-->
    <div class="container py-5">
        <h1 class="text-center">FASILITAS</h1>
        <div class="row gy-5">
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <div class="col-md-4">
                <img src="./asset/Background Home.jpg" width="100%" alt="" />
                <p>Ruang Kelas</p>
            </div>
            <!-- penutup fasilitas -->
            <!-- galeri -->
            <div class="beranda pt-5">
                <div class="container text-center">
                    <div class="pt-5u pb-5">
                        <h1>GALERI</h1>
                        <div class="owl-carousel owl-theme">
                            <div><img src="./asset/2.jpg" class="w-100" /></div>
                            <div><img src="./asset/2.jpg" class="w-100" /></div>
                            <div><img src="./asset/3.jpg" class="w-100" /></div>
                            <div><img src="./asset/3.jpg" class="w-100" /></div>
                            <div><img src="./asset/4.jpg" class="w-100" /></div>
                            <div><img src="./asset/4.jpg" class="w-100" /></div>
                            <div><img src="./asset/4.jpg" class="w-100" /></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- penutup galeri -->
    <div class="back-to-top" id="backToTopBtn" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </div>
@endsection
