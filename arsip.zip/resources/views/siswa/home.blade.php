@extends('master.template')
@section('Judul', 'TKIT BINA PRESTASI')
@section('content')
    <!-- banner -->
    <div class="banner">
        <div class="container text-center pb-5 pt-5">
            <div class="overlay">
                <h4 class="display-6">SELAMAT DATANG DI TKIT BINA PRESTASI</h4>
                <a href="pendaftaran.html" class="btn btn-primary">PENDAFTARAN SISWA BARU</a>
            </div>
        </div>
    </div>
    <!-- penutup banner -->
    <!-- deskripsi singkat -->
    <div class="history">
        <div class="container py-5" style="text-align: center">
            <h1>TKIT BINA PRESTASI</h1>
            <div class="" style="text-align: justify">
                <p>Taman Kanak-Kanak Islam Terpadu (TKIT) Bina Prestasi berdiri pada tahun 2014 yang berdiri di bawah
                    naungan Yayasan Insan Bina Prestasi yang dipimpinan oleh Tuty Munawaroh S.Pd.I.</p>
                <p>TKIT Bina Prestasi berkomitmen untuk memberikan pola pendidikan yang terbaik bagi anak-anak untuk
                    menyelenggarakan pendidikan yang berkesinambungan dan ramah anak. Kurikulum TKIT Bina Prestasi disusun
                    dengan mengusung nilai-nilai Islami sebagai dasar untuk mengembangkan karakter peserta didik.</p>
                <p>TKIT Bina Prestasi terbagi dalam kelompok PG (usia 3 tahun), Kelompok A (usia 4- 5 tahun) kelompok B
                    (usia 5-6 tahun). Proses pembelajaran berlangsung selama 5 kali dalam seminggu dengan menggunakan
                    pembelajaran sentra.</p>
            </div>
        </div>
    </div>
    <!-- penutup deskripsi singkat -->
    <!-- galeri -->
    <div class="beranda py-5">
        <div class="container text-center">
            <h1>GALERI</h1>
            <div class="owl-carousel owl-theme">
                <div><img src="./asset/2.jpg" class="w-100" /></div>
                <div><img src="./asset/2.jpg" class="w-100" /></div>
                <div><img src="./asset/3.jpg" class="w-100" /></div>
                <div><img src="./asset/3.jpg" class="w-100" /></div>
                <div><img src="./asset/4.jpg" class="w-100" /></div>
                <div><img src="./asset/4.jpg" class="w-100" /></div>
                <div><img src="./asset/4.jpg" class="w-100" /></div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <!-- penutup galeri -->
    <!-- biaya PPDB-->
    <section class="register-section py-5">
        <div class="container text-center">
            <h1>PPDB ONLINE 2024/2025</h1>
            <div class="row gy-4">
                <div class="col-md-4">
                    <div class="card card-body">
                        <h3>Uang Pendaftaran</h3>
                        <div class="icon-round">
                            <i class="fas fa-percent"></i>
                        </div>
                        <h5 class="text-decoration-line-through">Rp200.000</h5>
                        <h1>GRATIS</h1>
                        <p><s></s></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-body">
                        <h3>Uang Pangkal</h3>
                        <div class="icon-round">
                            <i class="fas fa-percent"></i>
                        </div>
                        <h5 class="text-decoration-line-through">Rp600.000</h5>
                        <h1>GRATIS</h1>
                        <p><s></s></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-body">
                        <h3>Uang Gedung</h3>
                        <div class="icon-round">
                            <i class="fas fa-percent"></i>
                        </div>
                        <h5 class="text-decoration-line-through">Rp500.000</h5>
                        <h1>GRATIS</h1>
                        <p><s></s></p>
                    </div>
                </div>
            </div>
            <div class="mx-auto pt-4"><a href="pendaftaran.html" class="btn btn-primary">DAFTAR SEKARANG</a>
            </div>
    </section>
    <!-- penutup biaya PPDB -->
    <!-- FAQ -->
    <div class="beranda py-5">
        <div class="container text-center">
            <h1>FREQUENTLY ASKED QUESTIONS</h1>
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <strong>Bagaimana Cara Daftar ke TKIT Bina Prestasi?</strong>
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <ul class="text-start">
                                <li>Datang langsung ke Kantor TKIT Bina Prestasi</li>
                                <li>Daftar online <a href="pendaftaran.html">Klik Disini</a></li>
                                <li>Info lebih lanjut mengenai PPDB hubungi admin <a href="kontak.html">Klik Disini</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <strong>Kurikulum yang digunakan di TKIT Bina Prestasi?</strong>
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="accordion-body text-start">Kami mengimplementasikan Kurikulum Merdeka melalui
                            pembelajaran sentra seni, sentra bahasa, dan sentra imtak.
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <strong>Fasilitas di TKIT Bina Prestasi</strong>
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                        <div class="accordion-body text-start">
                            <li>Kelas yang nyaman dalam menunjang pembelajaran.</li>
                            <li>Sekolah yang aman dari keramaian lalu lalang kendaraan.</li>
                            <li>Taman bermain berupa permainan outdoor.</li>
                            <li>Tempat tunggu untuk orangtua berupa saung.</li>
                            <li>Membiasakan shalat dhuha di Masjid.</li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- penutup FAQ -->
    <div class="back-to-top" id="backToTopBtn" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </div>
@endsection
