@extends('master.template')
@section('Judul', 'Kontak')
@section('content')
    <!-- kontak -->
    <div class="container py-5 menu">
        <h1 class="text-center">HUBUNGI KAMI</h1>
        <h5 class="text-center">Senin-Jumat (08.00-12.00)</h5>
        <div class="row pb-3">
            <div class="col-md-6">
                <input class="form-control form-control-lg mb-3" type="text" placeholder="Nama" />
                <input class="form-control form-control-lg mb-3" type="text" placeholder="Email" />
                <input class="form-control form-control-lg" type="text" placeholder="No. Phone" />
            </div>
            <div class="col-md-6">
                <textarea class="form-control form-control-lg" rows="5"></textarea>
            </div>
        </div>
        <div class="col-md-3 mx-auto text-center">
            <button type="button" class="btn btn-danger btn-lg">Kirim Pesan</button>
        </div>
    </div>
    </div>
    <section class="card register-section py-5">
        <div class="container text-center">
            <h1>KONTAK KAMI</h1>
            <div class="row gy-4">
                <div class="col-md-4">
                    <div class="card card-body">
                        <div class="icon-round">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h5>Villa Mutiara Pluit Blok F3 No. 43, RT 007, RW 009, Kel. Periuk, Kec. Periuk, Kota Tangerang,
                            Banten 15131</h5>
                        <p><s></s></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-body">
                        <div class="icon-round">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h5>tkitbinaprestasi@gmail.com</h5>
                        <p><s></s></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-body">
                        <div class="icon-round">
                            <i class="fab fa-whatsapp"></i>
                        </div>
                        <h5>0857-6554-9259</h5>
                        <p><s></s></p>
                    </div>
                </div>
            </div>
            <div class="row gy-4">
                <div class="row gy-4">
                    <div class="col-md-4">
                        <div class="card card-body">
                            <div class="icon-round">
                                <i class="fab fa-facebook"></i>
                            </div>
                            <h5>Tkit Bina Prestasi</h5>
                            <p><s></s></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-body">
                            <div class="icon-round">
                                <i class="fab fa-instagram"></i>
                            </div>
                            <h5>kelasbinaprestasi</h5>
                            <p><s></s></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card card-body">
                            <div class="icon-round">
                                <i class="fab fa-youtube"></i>
                            </div>
                            <h5>tutymunawaroh7767</h5>
                            <p><s></s></p>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <div class="container pb-3">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d321.5154504394251!2d106.59583193943097!3d-6.163449892266536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ff12cd50a4f3%3A0x2ccc3cdcb14bf622!2sBIMBEL%20%26%20TKIT%20Bina%20Prestasi!5e0!3m2!1sen!2sid!4v1716474462846!5m2!1sen!2sid"
            width="100%" height="450" style="border: 0" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- penutup kontak -->
    <div class="back-to-top" id="backToTopBtn" title="Go to top">
        <i class="fas fa-arrow-up"></i>
    </div>
@endsection
