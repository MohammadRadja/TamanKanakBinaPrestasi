<!-- footer -->
<footer>
    <p>Designed by Syifa Mufida Mawrin</p>
    <p>&copy; 2024 TKIT BINA PRESTASI. All rights reserved.</p>
</footer>
<!-- penutup footer -->