<?php $__env->startSection('judul', 'Profil & Account'); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h3>Profil Pengguna</h3>
        <form action="<?php echo e(route('siswa.profil.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo e($pengguna->nama_lengkap); ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($pengguna->email); ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password Baru (opsional)</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="mb-3">
                <label for="password_confirmation" class="form-label">Konfirmasi Password Baru</label>
                <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ProjectLaravel/ppdb-tk/resources/views/main/profil.blade.php ENDPATH**/ ?>