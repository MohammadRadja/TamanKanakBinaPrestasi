
<?php $__env->startSection('judul', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
        <!-- dashboard -->
        <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1>
             
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Documents\Project Laravel\ppdb-tk\resources\views/main/dashboard.blade.php ENDPATH**/ ?>