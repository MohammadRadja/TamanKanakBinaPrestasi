<?php $__env->startSection('judul', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <h1 class="h3 mb-3"><strong>Analytics</strong> Dashboard</h1>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-user-circle"></i> Informasi Siswa
                </div>
                <div class="card-body">
                    <?php if(isset($biodata)): ?>
                        <div class="mb-3">
                            <p><strong><i class="fas fa-user"></i> Nama:</strong> <?php echo e($biodata->nama_lengkap); ?></p>
                            <p><strong><i class="fas fa-map-marker-alt"></i> Alamat:</strong> <?php echo e($biodata->alamat); ?></p>
                            <p><strong><i class="fas fa-phone"></i> No HP:</strong> <?php echo e($biodata->no_hp); ?></p>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Biodata siswa belum diisi.</p>
                    <?php endif; ?>

                    <p><strong><i class="fas fa-file-alt"></i> Jumlah Nilai Raport:</strong> <?php echo e($jumlah_nilai_rapor); ?></p>

                    <?php if($jumlah_nilai_rapor > 0): ?>
                        <p><strong><i class="fas fa-chart-bar"></i> Rata-rata Nilai Raport:</strong> <?php echo e(number_format($rataRataNilai, 2)); ?></p>
                    <?php else: ?>
                        <p class="text-muted"><i>Belum ada data nilai raport.</i></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ProjectLaravel/ppdb-tk/resources/views/main/dashboard.blade.php ENDPATH**/ ?>