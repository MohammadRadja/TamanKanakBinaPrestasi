<!-- menu -->
<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('siswa.dashboard')); ?>">
            <span class="align-middle">TKIT BINA PRESTASI</span>
        </a>

        <ul class="sidebar-nav" id="sidebarMenu">
            <li class="sidebar-header">
                Pages
            </li>

            <li class="sidebar-item active">
<a class="sidebar-link" href="<?php echo e(route('siswa.dashboard')); ?>">
    <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
</a>

            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="<?php echo e(route('biodata.show', Session::has('pengguna_id') ? Session::get('pengguna_id') : '')); ?>">
                    <i class="align-middle" data-feather="user"></i> <span class="align-middle">Biodata Siswa</span>
                </a>
            </li>
            
          <li class="sidebar-item">
              <a class="sidebar-link" href="<?php echo e(route('siswa.raport')); ?>">
                  <i class="align-middle" data-feather="book"></i> <span class="align-middle">Raport</span>
              </a>
          </li>


        <li class="sidebar-item">
            <a class="sidebar-link" href="<?php echo e(route('siswa.jadwal')); ?>">
                <i class="align-middle" data-feather="calendar"></i> <span class="align-middle">Jadwal Masuk Sekolah</span>
            </a>
        </li>


            <li class="sidebar-header">
                Tools & Components
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="ui-buttons.html">
                    <i class="align-middle" data-feather="square"></i> <span class="align-middle">Buttons</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="ui-forms.html">
                    <i class="align-middle" data-feather="check-square"></i> <span class="align-middle">Forms</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="ui-cards.html">
                    <i class="align-middle" data-feather="grid"></i> <span class="align-middle">Cards</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="ui-typography.html">
                    <i class="align-middle" data-feather="align-left"></i> <span class="align-middle">Typography</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="icons-feather.html">
                    <i class="align-middle" data-feather="coffee"></i> <span class="align-middle">Icons</span>
                </a>
            </li>

            <li class="sidebar-header">
                Plugins & Addons
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="charts-chartjs.html">
                    <i class="align-middle" data-feather="bar-chart-2"></i> <span class="align-middle">Charts</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a class="sidebar-link" href="maps-google.html">
                    <i class="align-middle" data-feather="map"></i> <span class="align-middle">Maps</span>
                </a>
            </li>
        </ul>

        <div class="sidebar-cta">
            <div class="sidebar-cta-content">
                <strong class="d-inline-block mb-2">Upgrade to Pro</strong>
                <div class="mb-3 text-sm">
                    Are you looking for more components? Check out our premium version.
                </div>
                <div class="d-grid">
                    <a href="upgrade-to-pro.html" class="btn btn-primary">Upgrade to Pro</a>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /data/data/com.termux/files/home/ProjectLaravel/ppdb-tk/resources/views/ppdbtk/sidebar.blade.php ENDPATH**/ ?>