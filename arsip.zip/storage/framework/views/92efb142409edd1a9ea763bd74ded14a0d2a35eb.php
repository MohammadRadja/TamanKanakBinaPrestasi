<!-- footer -->
<footer>
    <p>Designed by Syifa Mufida Mawrin</p>
    <p>&copy; 2024 TKIT BINA PRESTASI. All rights reserved.</p>
</footer>
<!-- penutup footer --><?php /**PATH C:\Users\ASUS\OneDrive\Documents\Project Laravel\ppdb-tk\resources\views/master/footer.blade.php ENDPATH**/ ?>