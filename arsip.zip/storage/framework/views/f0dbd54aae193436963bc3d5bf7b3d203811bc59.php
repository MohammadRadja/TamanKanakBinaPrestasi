


<?php $__env->startSection('judul', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ProjectLaravel/ppdb-tk/resources/views/main/test.blade.php ENDPATH**/ ?>