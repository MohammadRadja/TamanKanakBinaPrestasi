<?php $__env->startSection('judul', 'Raport'); ?>

<?php $__env->startSection('content'); ?>
<div class="table-responsive">
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th>Mata Pelajaran</th>
                <th>Nilai</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $raport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($r->mapel); ?></td>
                <td><?php echo e($r->nilai); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="row mt-3">
    <div class="col-md-6">
        <h5>Rata-rata Nilai Raport</h5>
        <p><?php echo e($rataRataNilai); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdbtk.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/data/com.termux/files/home/ProjectLaravel/ppdb-tk/resources/views/main/raport.blade.php ENDPATH**/ ?>