    <!-- footer -->
    <footer class="bg-light">
        <div class="text-center p-3" style="background:#CCCCCC">Copyright &copy; 2024</div>
    </footer>
    <script type="text/javascript" src="admin.js"></script>
    <!-- penutup footer --><?php /**PATH C:\Users\ASUS\OneDrive\Documents\Project Laravel\ppdb-tk\resources\views/ppdbtk/footer.blade.php ENDPATH**/ ?>