
<?php $__env->startSection('Judul', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-5 pb-5 bg-light menu">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="container text-center">
            <h1>LOGIN</h1>
        </div>
        <div class="container">
            <form method="POST" action="<?php echo e(route('post.login')); ?>" class="row g-3">
                <?php echo csrf_field(); ?>
                <div class="col-md-4 mx-auto">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <p class="text-center">Belum Punya Akun? <a href="/register">Register Disini</a></p>
                    <div class="text-center mb-3">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\OneDrive\Documents\Project Laravel\ppdb-tk\resources\views/siswa/login.blade.php ENDPATH**/ ?>