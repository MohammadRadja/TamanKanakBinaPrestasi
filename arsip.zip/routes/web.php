<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PenggunaController;
use App\Http\Controllers\SiswaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('siswa.home');
});

Route::get('/profil', function () {
    return view('siswa.profil');
});

Route::get('/program', function () {
    return view('siswa.program');
});

Route::get('/kontak', function () {
    return view('siswa.kontak');
});

Route::get('/login', function () {
    return view('siswa.login');
})->name('login');


Route::get('/register', function () {
    return view('siswa.register');
});

Route::get('/biodata', function () {
    return view('main.biodata');
});


Route::get('/siswa/dashboard', [SiswaController::class, 'dashboard'])->name('siswa.dashboard');


Route::get('/siswa/biodata/{id}', [SiswaController::class, 'showBiodata'])->name('biodata.show');

Route::get('/siswa/profil', [SiswaController::class, 'profil'])->name('siswa.profil');

Route::post('/siswa/profil/update', [SiswaController::class, 'updateProfil'])->name('siswa.profil.update');

Route::get('/siswa/raport', [SiswaController::class, 'showRaport'])->name('siswa.raport');

Route::get('/siswa/jadwal-masuk-sekolah', [SiswaController::class, 'jadwalMasukSekolah'])->name('siswa.jadwal');



Route::post('/register', [PenggunaController::class, 'register'])->name('post.register');

Route::post('/login', [PenggunaController::class, 'login'])->name('post.login');

Route::post('/save', [SiswaController::class, 'biodatasave'])->name('biodata.save');

Route::post('/logout', [SiswaController::class, 'logout'])->name('logout');