<?php

namespace App\Http\Controllers;

use App\Models\Pengguna;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\BiodataDiri;
use App\Models\Raport;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\Models\JadwalMasukSekolah;
use App\Models\Siswa;

class SiswaController extends Controller
{
    public function __construct()
    {
        // Memeriksa apakah sesi pengguna_id sudah ada
        $this->middleware(function ($request, $next) {
            if (!Session::has('pengguna_id')) {
                return redirect('/login');
            }

            return $next($request);
        });
    }

public function dashboard()
    {
        // Pastikan pengguna sudah login
        if (!session('pengguna_id')) {
            return redirect()->route('login')->withErrors(['message' => 'Anda harus login terlebih dahulu.']);
        }

        // Ambil pengguna yang sedang login
        $pengguna_id = session('pengguna_id');

        // Ambil biodata siswa berdasarkan pengguna_id
        $biodata = BiodataDiri::where('pengguna_id', $pengguna_id)->first();

        // Ambil data siswa berdasarkan pengguna_id
        $siswa = Siswa::where('pengguna_id', $pengguna_id)->first();

        // Ambil jumlah nilai rapor siswa
        $jumlah_nilai_rapor = $siswa ? Raport::where('siswa_id', $siswa->id)->count() : 0;

        // Hitung ulang rata-rata nilai raport
        $rataRataNilai = $siswa ? Raport::where('siswa_id', $siswa->id)->avg('nilai') : 0;

        return view('main.dashboard', [
            'biodata' => $biodata,
            'siswa' => $siswa,
            'jumlah_nilai_rapor' => $jumlah_nilai_rapor,
            'rataRataNilai' => $rataRataNilai, // Menambahkan variabel rataRataNilai ke dalam view dashboard
        ]);
    }


    

    public function biodatasave(Request $request)
    {
        // Validasi input
        $request->validate([
            'fullName' => 'required',
            'nickName' => 'required',
            'gender' => 'required',
            'birthPlaceDate' => 'required',
            'agama' => 'required',
            'anakKe' => 'required',
            'parentNameAyah' => 'required',
            'parentNameIbu' => 'required',
            'profesiayah' => 'required',
            'profesiibu' => 'required',
            'telayah' => 'required',
            'address' => 'required',
        ]);

        try {
                        // Ambil pengguna berdasarkan session pengguna_id
                        $pengguna = Pengguna::findOrFail(Session::get('pengguna_id'));

                        // Simpan atau perbarui biodata
                        $biodata = BiodataDiri::updateOrCreate(
                            ['pengguna_id' => $pengguna->id],
                            [
                                'nama_lengkap' => $request->input('fullName'),
                                'nama_panggilan' => $request->input('nickName'),
                                'jenis_kelamin' => $request->input('gender'),
                                'tempat_tanggal_lahir' => $request->input('birthPlaceDate'),
                                'agama' => $request->input('agama'),
                                'anak_ke' => $request->input('anakKe'),
                                'nama_ayah' => $request->input('parentNameAyah'),
                                'nama_ibu' => $request->input('parentNameIbu'),
                                'pekerjaan_ayah' => $request->input('profesiayah'),
                                'pekerjaan_ibu' => $request->input('profesiibu'),
                                'no_hp' => $request->input('telayah'),
                                'alamat' => $request->input('address'),
                            ]
                        );
            
                        // Redirect kembali ke halaman profil dengan pesan sukses
                        return back()->with('success', 'Biodata berhasil disimpan.');
            
                    } catch (\Exception $e) {
                        // Jika terjadi kesalahan, redirect dengan pesan error
                        return back()->with('error', "Gagal menyimpan biodata. Silakan coba lagi. + $e");
                    }
                }
                // Contoh pada BiodataController
public function showBiodata($id)
{
    if($id != Session::get('pengguna_id')) {
        return back()->with('error', "Anda Tidak Memiliki Akses untuk Mengedit Data Ini");
    }
    // Ambil data biodata berdasarkan pengguna_id
    $biodata = BiodataDiri::where('pengguna_id', $id)->first();

    // Kirim data biodata ke view
    return view('main.bio', compact('biodata'));
}

    public function logout(Request $request)
    {
        // Hapus semua session
        Session::flush();

        // Redirect ke halaman login atau halaman lain sesuai kebutuhan
        return redirect('/login')->with('success', 'Anda telah logout.');
    }
    
public function profil()
{
    // Ambil informasi pengguna yang sedang login
    $pengguna = Pengguna::findOrFail(Session::get('pengguna_id'));

    // Kirim data pengguna ke view profil
    return view('main.profil', compact('pengguna'));
}

public function updateProfil(Request $request)
{
    $request->validate([
        'nama_lengkap' => 'required|string|max:100',
        'email' => 'required|string|email|max:100',
        'password' => 'nullable|string|min:6|confirmed', // tambahkan validasi password
    ]);

    try {
        // Ambil pengguna yang sedang login
        $pengguna = Pengguna::findOrFail(Session::get('pengguna_id'));

        // Perbarui informasi profil
        $pengguna->nama_lengkap = $request->input('nama_lengkap');
        $pengguna->email = $request->input('email');

        // Perbarui password jika dimasukkan
        if ($request->filled('password')) {
            $pengguna->password = Hash::make($request->input('password'));

            // Simpan perubahan profil
            $pengguna->save();

            // Hapus semua session
            Session::flush();

            // Redirect ke halaman login dengan pesan sukses
            return redirect('/login')->with('success', 'Password berhasil diubah. Silakan login kembali.');
        }

        // Simpan perubahan profil tanpa menghapus session
        $pengguna->save();

        return redirect()->route('siswa.profil')->with('success', 'Profil berhasil diperbarui.');
    } catch (\Exception $e) {
        return back()->withErrors(['error' => 'Gagal memperbarui profil. Silakan coba lagi.']);
    }
}

public function showRaport()
    {
        // Ambil data siswa berdasarkan pengguna yang sedang login
        $pengguna_id = session('pengguna_id');
        $siswa = Siswa::where('pengguna_id', $pengguna_id)->first();

        if (!$siswa) {
            return back()->withErrors(['message' => 'Data siswa tidak ditemukan.']);
        }

        // Ambil data raport berdasarkan siswa yang sedang login
        $raport = Raport::where('siswa_id', $siswa->id)->get();

        // Hitung rata-rata nilai raport
        $rataRataNilai = $raport->avg('nilai');

        // Kirim data raport dan rata-rata nilai ke view 'main.raport'
        return view('main.raport', compact('raport', 'rataRataNilai'));
    }
 
public function jadwalMasukSekolah()
    {
        $jadwal = JadwalMasukSekolah::all();
        return view('main.jadwal', compact('jadwal'));
    }
    
    
            }